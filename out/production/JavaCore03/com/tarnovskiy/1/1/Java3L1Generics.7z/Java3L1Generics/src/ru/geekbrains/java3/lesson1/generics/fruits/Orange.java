package ru.geekbrains.java3.lesson1.generics.fruits;

public class Orange extends Fruit {
}
