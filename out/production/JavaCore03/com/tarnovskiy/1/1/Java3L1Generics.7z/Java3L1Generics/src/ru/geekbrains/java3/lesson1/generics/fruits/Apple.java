package ru.geekbrains.java3.lesson1.generics.fruits;

public class Apple extends Fruit {
}
